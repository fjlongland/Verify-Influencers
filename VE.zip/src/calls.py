from openai import OpenAI
from .config import Settings

def basic_call(question):

    settings = Settings()

    api_key = settings.api_key

    messages = [
        {
            "role": "system",
            "content": (
                "You are an artificial intelligence assistant and you need to "
                "engage in a helpful, detailed, polite conversation with a user."
            ),
        },
        {
            "role": "user",
            "content": (
                f"{question}"
            ),
        },
    ]

    client = OpenAI(api_key=api_key, base_url="https://api.perplexity.ai")

    response = client.chat.completions.create(
        model="sonar-pro",
        messages=messages
    )

    answer = response.choices[0].message.content

    print(answer)




def about_influencer_call(name):

    settings = Settings()

    api_key = settings.api_key

    messages = [
        {
            "role": "system",
            "content": (
                "You are a detailed artificial intelegence and you will try harder to fill in all the information requested"
            ),
        },
        {
            "role": "user",
            "content": (
                f"Please provide information about {name} in a JSON format. Use the following structure and titles exactly: "
                "{"
                '"summary": "A brief one-paragraph summary of the person",'
                '"fields": ["List of fields he has worked in"],'
                '"yearly_revenue": "Estimated yearly revenue if available, or \'Not available\' if unknown",'
                '"online_followers": {'
                '    "total": "Total number of followers across all platforms",'
                '    "platform_breakdown": {'
                '        "Instagram": "Number of Instagram followers",'
                '        "Twitter": "Number of Twitter followers",'
                '        "YouTube": "Number of YouTube subscribers"'
                '    }'
                '},'
                '"products_released": {'
                '    "books": "Number of books published",'
                '    "courses": "Number of online courses released",'
                '    "podcasts": "Number of podcast series hosted"'
                '    "total": "total number of products released"'
                '},'
                '"reliability_score": "A percentage based on his claims cross-referenced against trusted scientific journals"'
                "} "
                f"Return only the JSON file, populated with the relavant information about {name}. "
                "If any information is not available, use an estimate as the value only for yearly revenue, in other cases you can user (not available)."
            ),
        },
    ]

    client = OpenAI(api_key=api_key, base_url="https://api.perplexity.ai")

    response = client.chat.completions.create(
        model="sonar-pro",
        messages=messages
    )

    answer = response.choices[0].message.content

    return answer